-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2026 at 04:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gala_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `ticket_type` varchar(50) NOT NULL,
  `ticket_price` int(11) DEFAULT 0,
  `food` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `age`, `ticket_type`, `ticket_price`, `food`) VALUES
(2, 'Dan Michael', 'danmciahel@gmail.com', '123', 20, 'Regular', 0, 'Regular Meal Set'),
(3, 'dabfa', 'dajhsdiajb@gmail.com', '123', 21, 'VIP', 0, 'Premium Meal Set'),
(4, 'Logan', 'logan@gmail.com', '234', 34, 'Regular', 0, NULL),
(5, 'Hana', 'hana@gmail.com', '123', 24, 'VIP', 0, 'Premium Meal Set'),
(6, 'fwjbkf', 'iujBASf', '12314', 12, 'Regular', 50, 'Premium Meal Set'),
(7, 'fgwseg', 'FadsgsH', '2353ADFG', 12, 'VIP', 400, 'Premium Meal Set'),
(8, 'GHZDRHSZDFTHJ', 'BDFHASTDFJ', 'egEW36', 23, 'VIP', 400, NULL),
(9, 'GZDRGHZ', 'ZBGDFH', 'ZDFH', 23, 'Regular', 50, NULL),
(10, 'agerhaerg', 'zgazdergh', 'zgdsg', 32, 'VIP', 400, 'Premium Meal Set');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
